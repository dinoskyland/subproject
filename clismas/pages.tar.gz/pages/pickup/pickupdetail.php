<?php
//display error 
ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);
include_once '../clisconnect.php';
if(!isset($_SESSION)) 
{ 
	session_start(); // Starting Session
} 

$pickup_no = $_POST['pickup_no'];
$subject = $_POST['subject'];
$subjectCode = $_POST['subjectCode'];
$visit = $_POST['visit'];
$dong = $_POST['dong'];
$nang = $_POST['nang'];
$shil = $_POST['shil'];
$status = 'requested';
$regidate = date("Y-m-d h:ia");
$register = $_SESSION['login_user'];

//insert kit
$sql = "INSERT INTO csm03_pickup_request_detail (pick_req_cd,sbj_cd,sbj_no,visit_name,spl_freezed_cnt,spl_cold_cnt,spl_room_temp_cnt,status,regidate,register) VALUES ('$pickup_no','$subjectCode','$subject','$visit','$dong','$nang','$shil','$status','$regidate','$register')";

if ($connClis->query($sql) === TRUE) {
    echo "1";
} else {
    echo "Error: " . $sql . "<br>" . $connClis->error;
}

?>
