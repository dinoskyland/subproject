<?php
include '../protocolsearch2.php';
include '../searchRequester.php';

if(!isset($_SESSION)) 
{ 
	session_start(); // Starting Session
} 

//if not allowed, go to blank.php
if ($_SESSION['manager'] == 'f' and $_SESSION['pick1'] == 'f') {
	header('Location: ../project/blank.php'); // Redirecting To Home Page	
}

$_SESSION['page']="pickup/pickuprequest.php";
if(!isset($_SESSION['login_user'])){
	header('Location: ../../index.php'); // Redirecting To Home Page
}

$user=$_SESSION['login_user'];
if($_SESSION['manager'] == 't'){
	$manager='관리자';
} else if($_SESSION['staff'] == 't'){
	$manager='Pickup Staff';
} else {
	$manager='일반사용자';	
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>CLISMAS</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<!-- Bootstrap 3.3.6 -->
	<link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
	<!-- selectpicker -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
  folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="../../plugins/datepicker/datepicker3.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../plugins/datatables/dataTables.bootstrap.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="../../plugins/iCheck/all.css">
  <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="../../plugins/timepicker/bootstrap-timepicker.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<!-- ADD THE CLASS layout-boxed TO GET A BOXED LAYOUT -->
<body class="hold-transition skin-blue sidebar-mini">
	<!-- Site wrapper -->
	<div class="wrapper">
		<header class="main-header">
			<!-- Logo -->
			<a href="../labresult/index.php" class="logo">
				<!-- mini logo for sidebar mini 50x50 pixels -->
				<span class="logo-mini"><b>CLISMAS</b></span>
				<!-- logo for regular state and mobile devices -->
				<span class="logo-lg"><b>CLISMAS</b></span>
			</a>
			<!-- Header Navbar: style can be found in header.less -->
			<nav class="navbar navbar-static-top">
				<!-- Sidebar toggle button-->
				<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
					<span class="sr-only">Toggle navigation</span>
				</a>

				<div class="navbar-custom-menu">
					<ul class="nav navbar-nav">

						<!-- User Account: style can be found in dropdown.less -->
						<li class="dropdown user user-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">
								<span class="hidden-xs"><?=$user?></span>
							</a>
							<ul class="dropdown-menu">
								<!-- User image -->
								<li class="user-header">
									<p>
										<?=$user?>
										<small id='manager'><?=$manager?></small>
									</p>
								</li>
								<!-- Menu Footer-->
								<li class="user-footer">
									<div class="pull-left">
										<a href="#" class="btn btn-default btn-flat">Profile</a>
									</div>
									<div class="pull-right">
										<a href="../login/logout.php" class="btn btn-default btn-flat">Log out</a>
									</div>
								</li>
							</ul>
						</li>
					</ul>
				</div>
			</nav>
		</header>

		<!-- =============================================== -->

		<aside class="main-sidebar">
			<!-- sidebar: style can be found in sidebar.less -->
			<section class="sidebar">
				<!-- Sidebar user panel -->
				<!-- sidebar menu: : style can be found in sidebar.less -->
				<ul class="sidebar-menu">
					<li class="treeview">
						<a href="#">
							<i class="fa fa-flask"></i><span>Lab Result</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">
							<li><a href="../labresult/index.php"><i class="fa fa-circle-o"></i> Real Time Test Result</a></li>
							<li><a href="../labresult/statistics.php"><i class="fa fa-circle-o"></i> Result Statistics</a></li>
						</ul>
					</li>
					<li class="active">
						<a href="pickuprequest.php" id='pickuprequest'>
							<i class="fa fa-plus-square"></i><span>Pickup Request</span>
						</a>
					</li>
					<li>
						<a href="../kit/kitorder.php">
							<i class="fa fa-reorder"></i><span>Kit Order</span>
						</a>
					</li>
					<li class="treeview">
						<a href="#">
							<i class="fa fa-file-o"></i><span>Result Report</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">
							<li><a href="../report/resultreport.php"><i class="fa fa-circle-o"></i> Result Report</a></li>
							<li><a href="../report/rereport.php"><i class="fa fa-circle-o"></i> Re-Report</a></li>
							<li><a href="../report/reportlog.php"><i class="fa fa-circle-o"></i> Report Log</a></li>
						</ul>
					</li>
					<li class="treeview">
						<a href="#">
							<i class="fa fa-wrench"></i><span>Project</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">
							<li><a href="../project/kitsetup.php"><i class="fa fa-circle-o"></i> 안건별KIT설정</a></li>
							<li><a href="../project/register.php"><i class="fa fa-circle-o"></i> 사용자등록</a></li>
							<li><a href="../project/usermodify.php"><i class="fa fa-circle-o"></i> 사용자수정</a></li>
							<li><a href="../project/hospitalallocate.php"><i class="fa fa-circle-o"></i> StaffSite연결</a></li>
							<li><a href="../project/confirm.php"><i class="fa fa-circle-o"></i> 사용자인증</a></li>
							<li><a href="../project/partners.php"><i class="fa fa-circle-o"></i> 업체조회</a></li>
						</ul>
					</li>
				</ul>
			</section>
			<!-- /.sidebar -->
		</aside>

		<!-- =============================================== -->

		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<h1>
					Pickup Request
				</h1>
				<ol class="breadcrumb">
					<li><a href="../labresult/index.php"><i class="fa fa-dashboard"></i> Home</a></li>
					<li class="active">Pickup Request</li>
				</ol>
			</section>

			<!-- Main content -->
			<section class="content">
				<!-- Main row -->
				<div class="box" id='top'>
					<!-- Chat box -->
					<div class="box box-success">
						<form class="form-horizontal" method="post" action="<?php echo ($_SERVER["PHP_SELF"]);?>">
							<div class="box-body">
								<div class="form-group">
									<label for="protocol" class="col-md-2 control-label">안건코드</label>
									<div class="col-md-10">
										<div class="row">
											<div class="col-md-5">
												<select class="form-control selectpicker" name="protocol" id='protocol'>
													<?php include '../protocolselect.php'; ?>
												</select>
											</div>
											<div class="col-md-5">
												<?php if($_SESSION['manager'] == 't'){
													//show or hide search button
													//manager
													echo "<button type='submit' class='btn btn-primary' id='search' name='search'>Search</button>";
												} else {
													//user
												}
												?>
											</div>
										</div>
									</div>
								</div>

								<div class="form-group">
									<label for="site" class="col-md-2 control-label">Site명</label>
									<div class="col-md-10">
										<div class="row">
											<div class="col-md-5">
												<select class='form-control selectpicker' name='site' id='site'>
													<?php if($_SESSION['manager'] == 't')
													{include '../siteselect.php';}
													else {echo '<option>'.$site.'</option>';} 
													?>
												</select>
											</div>										
											<div class="col-md-5">
												<?php if($_SESSION['manager'] == 't'){
												//show or hide search button
												//manager
													echo "<button type='submit' class='btn btn-primary' id='searchRequester' name='searchRequester'>Search Requester</button>";
												} else {	//user
												}?>
											</div>										
										</div>										
									</div>
								</div>
								<!-- /.form group -->
								
								<!-- Date -->
								<div class="form-group">
									<label for="datepicker" class="col-md-2 control-label">Pickup Date</label>
									<div class="col-md-10">
										<div class="row">
											<div class="col-md-3" style='padding-right:0px;'>
												<div class="input-group date">
													<input type="text" class="form-control pull-right" id="datepicker" name="datepicker">
												</div>
											</div>
											<div class="col-md-2" style='padding-left:0px; padding-right:0px; margin-right:0px; font-weight: bold; width:80px'>
												<p class="margin" style="">문자발송</p>
											</div>
											<!-- /.input group -->
											<div class="col-md-5" style='margin-left:0px; padding-left:0px;'>
												<p class="margin" id='sendtext'>09:00 am</p>
											</div>
										</div>
									</div>
								</div>
								<!-- /.form group -->
								<!-- text input -->
								<div class="form-group">
									<label class="col-md-2 control-label">Pickup Time</label>
									<div class="col-md-10">
										<div class="row">
											<div class="col-md-3">
												<p class="margin">09:00am - 10:00am</p>
											</div>
											<div class="col-md-7">
												<p class="margin"></p>
											</div>
										</div>
									</div>
								</div>
								<!-- /.form-group -->
								<!-- radio -->
								<div class="form-group">
									<label class="col-md-2 control-label">Storage Condition</label>
									<div class="col-md-10">
										<div class="row">
											<div class="col-md-3">
												<label style="margin-top:5px";>
													<input type="radio" name="dong" class="minimal" value='dongYes' checked>
													동결검체있음
												</label>
											</div>
											<div class="col-md-3">
												<label style="margin-top:5px";>
													<input type="radio" name="dong" class="minimal" value="dongNo">
													동결검체없음
												</label>
											</div>
											<div class="col-md-4">
											</div>
										</div>
									</div>
								</div>


								<div class="form-group">
									<label class="col-md-2 control-label">Quantity</label>
									<div class="col-md-10">
										<div class="row">
											<div class="col-md-2">
												<input type="text" class="form-control" id="quantity" name="quantity">
											</div>
											<div class="col-md-2">
												<button type="button" class="btn btn-primary pull-left" id="input">Input</button>
											</div>
											<div class="col-md-6">
											</div>
										</div>
									</div>
								</div>

								<div class="form-group">
									<label class="col-md-2 control-label"></label>
									<div class="col-md-10">
										<div class="row">
											<div class="col-md-8" id='quantityTableDiv'>
												<table class="table table-bordered" id="quantityTable2">
													<thead>
														<tr>								
															<th></th>
															<th style="width: 30%">Subject No.</th>
															<th>방문주수명</th>
															<th>동결검체수</th>
															<th>냉장검체수</th>
															<th>실온검체수</th>
														</tr>
													</thead>
													<tbody>							
													</tbody>
												</table>
											</div>
											<div class="col-md-2">
											</div>
										</div>
									</div>
								</div>

								<!-- text input -->
								<div class="form-group">
									<label class="col-md-2 control-label">Pickup Staff</label>
									<div class="col-md-8">
										<p class="margin" >주담당자 <span id='staff1' name='<?=$staff1name?>' style='padding-left:10px'><?=$staff1phone?></span></p>
									</div>
									<div class="col-md-8 col-md-offset-2">
										<p class="margin">부담당자 <span id='staff2' name='<?=$staff2name?>' style='padding-left:10px'><?=$staff2phone?></span></p>
									</div>
								</div>
								<!-- /.form-group -->

								<!-- text input -->
								<div class="form-group">
									<label class="col-md-2 control-label">연구간호사연락처</label>
									<div class="col-md-10">
										<div class="row">
											<div class="col-md-5">
												<span name='phone' id='phone' class="form-control"><?=$phone?></span>
											</div>
										</div>
									</div>
								</div>
								<!-- /.form-group -->
							</div>
						</form>
					</div>
					<!-- /.box-body -->
				</div>
				<!-- /.box box-success -->

				<div class="box">
					<div class="box-header">
						<h3 class="box-title">Subject List</h3>
					</div>
					<!-- /.box-header -->
					<form class="form-horizontal checked">
						<div class="box-body">
							<table id="example2" class="table table-bordered table-hover">
								<thead>
									<tr>
										<th>Request No.</th>
										<th>Site명</th>
										<th>요청자</th>
										<th>Subject No.</th>
										<th>Visit</th>
										<th>동결/냉장/실온 검체수</th>
										<th>Pickup Request Date</th>
										<th>Status</th>
										<th>Status changed at</th>
										<th>by</th>
									</tr>
								</thead>
								<tbody>
									<?php if($manager != 'Pickup Staff') {
										include 'pickupsubjectlist.php'; }
										else { include 'pickupsubjectlistForStaff.php'; } ?>	
									</tbody>
								</table>
							</div>
							<div class="box-footer">
							</div>
						</form>
					</div>
					<!-- /.box -->
				</section>
				<!-- /.content -->
			</div>
			<!-- /.content-wrapper -->
<!-- 		<footer class="main-footer">
			<div class="pull-right hidden-xs">
				<b>Version</b> 2.3.5
			</div>
			<strong>Copyright &copy; 2014-2016 <a href="http://almsaeedstudio.com">Almsaeed Studio</a>.</strong> All rights
			reserved.
		</footer> -->
		<div class="control-sidebar-bg"></div>
	</div>
	<!-- ./wrapper -->

	<!-- Button modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id='myModal'>
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">Order No.
						<span id='delivery_order_no', name='delivery_order_no'>
						</span>
					</h4>
				</div>
				<div class="modal-body">
					<table class="table table-bordered" id="pickuptable">
						<thead>
							<tr>								
								<th>동결검체수</th>
								<th>냉장검체수</th>
								<th>실온검체수</th>
							</tr>
						</thead>
						<tbody>
							
						</tbody>
					</table>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary" id='pickedup'>Save</button>
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->


	<!-- jQuery UI 1.11.4 -->
	<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script>
		$.widget.bridge('uibutton', $.ui.button);
	</script>
	<!-- jQuery 2.2.4 -->
	<script src="http://code.jquery.com/jquery-2.2.4.min.js" ></script>
	<!-- Bootstrap 3.3.6 -->
	<script src="../../bootstrap/js/bootstrap.min.js"></script>
	<!-- selectpicker -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>
	<!-- bootstrap datepicker -->
	<script src="../../plugins/datepicker/bootstrap-datepicker.js"></script>
	<script src="../../plugins/datepicker/locales/bootstrap-datepicker.kr.js"></script>
	<!-- bootstrap time picker -->
	<script src="../../plugins/timepicker/bootstrap-timepicker.min.js"></script>
	<!-- SlimScroll 1.3.0 -->
	<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
	<!-- iCheck 1.0.1 -->
	<script src="../../plugins/iCheck/icheck.min.js"></script>
	<!-- FastClick -->
	<script src="../../plugins/fastclick/fastclick.js"></script>
	<!-- AdminLTE App -->
	<script src="../../dist/js/app.min.js"></script>
	<!-- DataTables -->
	<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript" src="pickuprequest.js"></script>


	<!-- Page script -->
	<script>
		$(function () {
    //Date picker
    $('#datepicker').datepicker({
    	language: 'kr',
    	format: 'yyyy-mm-dd',
    	autoclose: true
    });

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
    	checkboxClass: 'icheckbox_minimal-blue',
    	radioClass: 'iradio_minimal-blue'
    });

    $('#example2').DataTable({
    	"paging": true,
    	"lengthChange": false,
    	"searching": false,
    	//"ordering": true,
    	"order": [[0, "desc" ]],
    	"info": true,
    	"autoWidth": false
    });
    //Timepicker
    $(".timepicker").timepicker({
    	showInputs: false
    });

    $('#myModal').modal({
    	show: false,
    	backdrop: 'static'
    });



});
</script>

</body>
</html>
