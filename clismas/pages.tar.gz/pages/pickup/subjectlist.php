<?php
//get subject info from bim05_subjects table with protocol and site
//which is used in modal

//display error 
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');

include_once '../limsconnect.php';

$options='';
$protocol=$_POST['protocol'];
$site=$_POST['site'];

$sql = "SELECT sbj_cd,sbj_no FROM bim05_subjects where ptl_cd='$protocol' and sbj_site='$site'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        $options=$options."<option id='{$row['sbj_cd']}'>{$row['sbj_no']}</option>";                       
    }
} else {
    echo "0 results";
}

echo $options;
?>
