$(function() {
	if ($('#manager').text() == 'Pickup Staff') {
		$('#top').hide();
	}

	$("#quantityTable2").hide();

	$("#input").click(function(){
		var protocol = $('#protocol').val();
		var site = $('#site').val();
		var datepicker = $("#datepicker").val();

		if (site.length == 0) {
		    alert('안건코드 search를 먼저 해주세요');			
		} else if (datepicker.length == 0) {
			alert('Pickup Date을 입력해주세요');	
		} else {
			$.post( "subjectlist.php", {
				protocol:protocol, 
				site:site
				}, function(data) {
				console.log("subjectlist  " + data);
				subjectList(data);
				//alert( data );
			})
			.fail(function() {
				alert(data);
			}); // end ajax call				

			
			function subjectList(data) {
				var quantity = $('#quantity').val();
				var pattern_num = /^([0-9]|[0-9][0-9]|[0-9][0-9][0-9])$/;

				 if (quantity.match(pattern_num)) {
					$("#quantityTable2").show();
					$("#quantityTable2 > tbody > tr").remove();
		    		$("#quantityTableDiv button").remove();
					//quantity=Number(quantity);
		    		tr='';
					console.log('match'+quantity);
		    		for (i = 0; i < quantity; i++) {
		    			tr = tr + "<tr>";
		    			tr = tr + "<td id='counter'>"+(i+1)+"</td>";
		    			tr = tr + "<td><select class='form-control subject'>"+
		    						data+
		    						"</select></td>";
		    			tr = tr + "<td><input type='text' class='form-control visit'></td>";
		    			tr = tr + "<td><input type='text' class='form-control dong'></td>";
		    			tr = tr + "<td><input type='text' class='form-control nang'></td>";
		    			tr = tr + "<td><input type='text' class='form-control shil'></td>";
		    			tr = tr + "</tr>";
		    		}
		    		$("#quantityTable2 > tbody").append(tr);	
		    		var finished = '<button type="button" class="btn btn-primary pull-right" id="submitRequest">Submit Request</button>';
		    		$("#quantityTableDiv").append(finished);

				} else {
					$("#quantityTable2").hide();
					$("#quantityTable2 > tbody > tr").remove();
		    		$("#quantityTableDiv button").remove();

					alert('수량을 입력해 주세요');
				}		
			}
			
		}

	});


	$(document).on('click', '#submitRequest', function(){ 
		$.ajaxSetup({async:false});//execute synchronously
		var pickup_no = '';
		var isRequestSaved = 0;

		var quantity = $("#quantity").val();
		var pattern_num = /^([0-9]|[0-9][0-9]|[0-9][0-9][0-9])$/;

		if (quantity.length == 0) {
    		alert("Quantity = 0\n요청불가");
		} else if (quantity.match(pattern_num)) {
			$('#quantityTable2 > tbody  > tr').each(function() {
				$this = $(this);
				var counter = $this.find("#counter").text();
				var subject = $this.find("select.subject").val();
				var subjectCode = $this.find("input.subject").prop('id');
				var visit = $this.find("input.visit").val();
				var dong = $this.find("input.dong").val();
				var nang = $this.find("input.nang").val();
				var shil = $this.find("input.shil").val();
				var pattern_num = /^([0-9]|[0-9][0-9]|[0-9][0-9][0-9])$/;
				var pattern = /^[ㄱ-ㅎㅏ-ㅣ가-힣\s\w-()]+$/;

				$.post( "pickup_no.php", function(data) {
					console.log('pickup_no.'+data);
					pickup_no = data;			
					//kitordermaster(data, ordersummary);
				})
				.fail(function() {
					alert(data);
				}); // end ajax call	

				if (!visit.match(pattern)) {
			    	alert(counter+'-->방문주수명: 문자,순자,(),_,-만 가능합니다');
			    	quantity--;			
				} else if (!dong.match(pattern_num) && dong.length!=0) {
			    	alert(counter+'-->동결검체수: 순자만 가능합니다');			
			    	quantity--;			
				} else if (!nang.match(pattern_num) && nang.length!=0) {
			    	alert(counter+'-->냉장검체수: 순자만 가능합니다');			
			    	quantity--;			
				} else if (!shil.match(pattern_num) && shil.length!=0) {
			    	alert(counter+'-->실온검체수: 순자만 가능합니다');			
			    	quantity--;			
				} else {
		    		//alert(subject + visit + dong+ nang + shil);
					$.post( "pickupdetail.php", {
						pickup_no:pickup_no, 
						subject:subject, 
						subjectCode:subjectCode, 
						visit:visit, 
						dong:dong, 
						nang:nang, 
						shil:shil
						}, function(data) {
						console.log("kitorderdetail");
						isRequestSaved = 1;
						//alert( data );
					})
					.fail(function() {
						alert(data);
					}); // end ajax call				
				}
			});		

			if (isRequestSaved == 1) {
				var datepicker = $("#datepicker").val();
				var sendtext = $("#sendtext").val();
				var dongCondition = $('input:radio[name=dong]:checked').val();
				var staff1name = $("#staff1").attr('name');
				var staff2name = $("#staff2").attr('name');
				var staff1phone = $("#staff1").text();
				var staff2phone = $("#staff2").text();
				console.log('datepicker '+datepicker);
				console.log('sendtext '+sendtext);

				var visitTimeFrom = $("#visitTimeFrom").val();
				var visitTimeTo = $("#visitTimeTo").val();
				var visitTime = visitTimeFrom+'-'+visitTimeTo;
				if (dongCondition == 'dongYes') {
					dongCondition = '동결검체있음';
				} else {
					dongCondition = '동결검체없음';

				}
				$.post( "pickupmaster.php", {
					pickup_no:pickup_no, 
					datepicker:datepicker, 
					dongCondition:dongCondition, 
					staff1name:staff1name, 
					staff2name:staff2name, 
					staff1phone:staff1phone, 
					staff2phone:staff2phone, 
					visitTime:visitTime, 
					quantity:quantity,
					sendtext:sendtext
					}, function(data) {
					console.log("pickupmaster"+data);
					alert(data);
					//alert( data );
					window.location.href = $("#pickuprequest").prop('href');
				})
				.fail(function() {
					alert(data);
				}); // end ajax call		
		
			} else {
				
			}
		} else {
    		alert("Quantity: 숫자만 입력가능합니다(1~999)\n요청불가");

		}

 	});

	var pickupNumber;
	var pickupStatus;
	var pickupIdDetail;
	$(".pickupNumber").click(function(){
		pickupStatus = $(this).parent().next().next().children().text();
		pickupNumber = $(this).text();
		pickupIdDetail = $(this).prop('id');
	});
	
	//when modal in open
	$('#myModal').on('show.bs.modal', function (event) {
/*		if(pickupStatus == 'completed' || pickupStatus == 'canceled') {
			e.stopPropagation();
		}  */
		if(pickupStatus == 'canceled') {
			e.stopPropagation();
		}  
		var res = pickupNumber.split("/");
		$("#pickuptable > tbody > tr").remove();
		tr = "<tr>";
		tr = tr + "<td>"+(res[0].split("("))[0]+"</td>";
		tr = tr + "<td>"+(res[1].split("("))[0]+"</td>";
		tr = tr + "<td>"+(res[2].split("("))[0]+"</td>";
		tr = tr + "<tr>";
		tr = tr + "<tr>";
		tr = tr + "<td><input type='text' id='pickupDong' class='form-control'></td>";
		tr = tr + "<td><input type='text' id='pickupNang' class='form-control'></td>";
		tr = tr + "<td><input type='text' id='pickupShil' class='form-control'></td>";
		tr = tr + "<tr>";
		
		$("#pickuptable > tbody").append(tr);					
	});

	//save
	$("#pickedup").click(function(){
    	$('#myModal').modal('hide');
		$this = $('#pickuptable > tbody  > tr').eq(2);
		var pickupDong = $this.find("#pickupDong").val();
		console.log(pickupDong);
		var pickupNang = $this.find("#pickupNang").val();
		console.log(pickupNang);
		var pickupShil = $this.find("#pickupShil").val();
		console.log(pickupShil);
		var pattern_num = /^([0-9]|[0-9][0-9]|[0-9][0-9][0-9])$/;
		console.log('id '+pickupIdDetail);

		if (!pickupDong.match(pattern_num) && pickupDong!='') {
			alert('동결검체수: 숫자만 입력하세요');
			//blank
		//update send_qty(kits sent) from csm04_KIT_order_detail;_
		} else if (!pickupNang.match(pattern_num) && pickupNang!='') {
			alert('냉장검체수: 숫자만 입력하세요');
			//blank
		//update send_qty(kits sent) from csm04_KIT_order_detail;_
		} else if (!pickupShil.match(pattern_num) && pickupShil!='') {
			alert('실온검체수: 숫자만 입력하세요');
			//blank
		//update send_qty(kits sent) from csm04_KIT_order_detail;_
		} else if (pickupDong=='' && pickupNang=='' && pickupShil=='') {
			alert('숫자를 입력하세요');
			//blank
		//update send_qty(kits sent) from csm04_KIT_order_detail;_
		} else {
			$.post( "pickedup.php", {
				id:pickupIdDetail,
				pickupDong:pickupDong,
				pickupNang:pickupNang,
				pickupShil:pickupShil
				}, function(data) {
				//console.log("delivered");
				//alert( data );
				window.location.href = $("#pickuprequest").prop('href');
			})
			.fail(function() {
				alert(data);
			}); // end ajax call				

		}

	});

	$(".statusChangedForUser").click(function(){
		var id = $(this).prop('id');
		var status = $(this).text();

		if (status == 'requested') {
			if (confirm("삭제하시겠습니까?")) {
				$.post( "cancelPickup.php", {
					id:id,
					}, function(data) {
					//console.log("delivered");
					alert( data );
					window.location.href = $("#pickuprequest").prop('href');
				})
				.fail(function() {
					alert(data);
				}); // end ajax call						
			}
		}


	});

	$(".statusChangedForStaff").click(function(){
		var id = $(this).prop('id');
		var status = $(this).text();

		if (status != 'canceled') {
			if (confirm("삭제하시겠습니까?")) {
				$.post( "cancelPickup.php", {
					id:id,
					}, function(data) {
					//console.log("delivered");
					//alert( data );
					window.location.href = $("#pickuprequest").prop('href');
				})
				.fail(function() {
					alert(data);
				}); // end ajax call						
			}
		}
	});


});
