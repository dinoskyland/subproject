<?php
//display error 
ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);
include_once '../clisconnect.php';
if (!isset($_SESSION)) {
    session_start(); // Starting Session
}
//if (isset($_POST['submit'])) {

if (isset($_SESSION['site'])) {
    $protocol_name = $_SESSION['protocolname'];
    $site          = $_SESSION['site'];
    
    $sql = "SELECT pick_req_cd,site_name,regidate,requester,pickup_date,change_datetime FROM csm03_spl_pickup_request where protocol_name='$protocol_name' and site_name='$site'";
    
    $result = $connClis->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            $pickupNo    = $row["pick_req_cd"];
            $site        = $row["site_name"];
            $requestDate = $row["regidate"];
            $requester   = $row["requester"];
            $pickupDate  = $row["pickup_date"];
            //$changed     = $row["change_datetime"];
            // $id          = $row["register"];
            
            $sql = "SELECT id,sbj_no,visit_name,spl_freezed_cnt,spl_cold_cnt,spl_room_temp_cnt,spl_freezed_picked,spl_cold_picked,spl_room_temp_picked, status,regidate,register  FROM csm03_pickup_request_detail where pick_req_cd='$pickupNo'";
            
            $result2 = $connClis->query($sql);
            
            if ($result2->num_rows > 0) {
                // output data of each row
                while ($row = $result2->fetch_assoc()) {
                    $strTd = "<a href='javascript:void(0)' class='btn btn-default btn-block pickupNumber' id='{$row['id']}'>";
                    if ($row["spl_freezed_cnt"] > $row["spl_freezed_picked"]) {
                        $strTd = $strTd . $row["spl_freezed_cnt"] . "(" . "<span style='color:red'>" . $row["spl_freezed_picked"] . "</span>" . ")" . " / ";
                    } else {
                        $strTd = $strTd . $row["spl_freezed_cnt"] . "(" . $row["spl_freezed_picked"] . ")" . " / ";
                    }
                    if ($row["spl_cold_cnt"] > $row["spl_cold_picked"]) {
                        $strTd = $strTd . $row["spl_cold_cnt"] . "(" . "<span style='color:red'>" . $row["spl_cold_picked"] . "</span>" . ")" . " / ";
                    } else {
                        $strTd = $strTd . $row["spl_cold_cnt"] . "(" . $row["spl_cold_picked"] . ")" . " / ";
                    }
                    if ($row["spl_room_temp_cnt"] > $row["spl_room_temp_picked"]) {
                        $strTd = $strTd . $row["spl_room_temp_cnt"] . "(" . "<span style='color:red'>" . $row["spl_room_temp_picked"] . "</span>" . ")";
                    } else {
                        $strTd = $strTd . $row["spl_room_temp_cnt"] . "(" . $row["spl_room_temp_picked"] . ")";
                    }
                    $strTd = $strTd . "</a>";
                    
                    echo "<tr>";
                    echo "<td>" . $pickupNo . "</td>";
                    echo "<td>" . $site . "</td>";
                    // echo "<td>" . $requestDate . "</td>";
                    echo "<td>" . $requester . "</td>";
                    echo "<td>" . $row["sbj_no"] . "</td>";
                    echo "<td>" . $row["visit_name"] . "</td>"; //visit
                    echo "<td>" . $strTd . "</td>"; //visit
                    echo "<td>" . $pickupDate . "</td>";
                    echo "<td><a href='javascript:void(0)' class='btn btn-default btn-block statusChangedForUser' id='{$row['id']}'>" . $row["status"] . "</span></td>";
                    echo "<td>" . $row["regidate"] . "</td>";
                    echo "<td>" . $row["register"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "0 results in";
            }
        }
    } else {
        echo "0 results out";
    }
    //}
    
}
$connClis->close();


?>
