<?php
//display error 
ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);
if (!isset($_SESSION)) {
    session_start(); // Starting Session
}

include_once '../clisconnect.php';

// prepare and bind
$stmt = $connClis->prepare("UPDATE csm03_spl_pickup_request_staff set manager_name=?,mobile=?,role=? where user_ID=?");
$stmt->bind_param("ssss", $staffperson, $staffphone, $staffrole, $userid);

$staffperson = $_POST['staffperson'];
$staffphone  = $_POST['staffphone'];
$staffrole   = $_POST['staffrole'];
$userid      = $_SESSION['usermodify'];

// $protocol = strip_tags($protocol);
// $userid = strip_tags($userid);
// $password = strip_tags($password); 

if ($stmt->execute() === TRUE) {
    echo '수정되었습니다';
} else {
    echo "Error: " . $connClis->error;
}
$stmt->close();
$connClis->close();

?>
