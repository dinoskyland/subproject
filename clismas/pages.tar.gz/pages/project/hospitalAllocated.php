<?php			
//display error 
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
include_once '../clisconnect.php';

$temp = explode('/', $_POST['staff']);
$staffName = $temp[0];
$staffPhone = $temp[1];
$role = $temp[2];
$staffId = $temp[3];

$added=false;
if (isset($_POST['submit'])) {
	for ($i = 1; $i <= 13; $i++){
		$hospital='hospital'.$i;
		$hospital = $_POST[$hospital];
		if ($hospital!='') {
			$stmt = $connClis->prepare("INSERT INTO csm03_spl_pickup_request_staff (user_ID,site_name, manager_name, mobile, role) VALUES (?, ?, ?, ?, ?)");
			$stmt->bind_param("sssss", $staffId, $hospital, $staffName, $staffPhone, $role);

			if ($stmt->execute() === TRUE) {
				$added = true;
			} else {
			    echo "Error: " . $connClis->error;
			}
			$stmt->close();
		}	
	}
	if ($added) {
		echo "<script>alert('입력되었습니다')</script>";
		//header("refresh:0; url=hospitalallocate.php" );
	}
	
} else if (isset($_POST['delete'])) {
	$hospital = $_POST['hospitalX'];

	if ($hospital!='') {
		$sql = "DELETE FROM csm03_spl_pickup_request_staff
	        WHERE site_name='$hospital'and user_ID='$staffId'";
		if ($connClis->query($sql) === TRUE) {
		    $added = true;
			echo "<script>alert('삭제되었습니다')</script>";
		} else {
		    echo "Error deleting record: " . $connClis->error;
		}
	} else {
		
		echo "<script>alert('병원을 선택해주세요')</script>";
	}

}
header("refresh:0; url=hospitalallocate.php" );

$connClis->close();

?>
