// Bind to the submit event of our form
$(function() {
	//protocol search
/*	$("#search").click(function(){
		var protocol = $("#protocol").val();

		$.post( "../protocolsearch.php", {protocol: protocol}, function(data) {
			// var json = $.parseJSON(data);
		   //  		alert(json.result[0].pl_protocol_name);
		   $("#protocolname").val(data[0].pl_protocol_name);
		   $("#period").val(data[0].pl_study_begin+' ~ '+data[0].pl_study_end);
		   $("#sponsor").val(data[0].pl_sponser_name);
		   $("#info").val('대표PI: '+data[0].pl_PI_name+'\n'+'대상질병: '+data[0].pl_diseases+'\n'+'견적비용: '+data[0].pl_estimate_cost);
		   //alert(data);
		},'json')
		.fail(function() {
			alert( "안건코드 입력확인" );
		}); // end ajax call		
	});

	$("#kitinsert").click(function(){
			alert( "안건코드 입력확인" );
	});
*/

	$(".kitmodify").click(function(){
    	var values = $(this).attr("id");
    	var kitname = $(this).parent().prevAll().eq(2).children().val();
/*    	var kitname = $(this).parent().prev().prev().prev().children().val();
*/    	
		console.log(kitname);
    	$.post( "kitmodify.php", {id: values, kitname:kitname}, function(data) {
			// alert( data );
			alert( "수정되었습니다" );
    	})
    	.fail(function() {
			alert( data );
		}); // end ajax call
	});

	$(".kitdelete").click(function(){
    	var values = $(this).attr("id");
		// $(this).parent().prev().children().hide();
    	console.log('kitdelete id '+values);
		var returnVal = confirm("Order를 삭제하시겠습니까?");
        if (returnVal) {
	    	$.post( "kitdelete.php", {id: values}, function(data) {
				console.log('kitdelete return: '+data);
	    		if (data==1) {
	/*				$this.hide();
					$this.parent().prev().children().hide();
		    		alert("Kit: 삭제되었습니다");
	*/	    		
					$("#search").click(); //refresh webpage
	    		} else {
		    		alert("Kit Order가 있어 삭제할 수 없습니다");
	    		}
	    	})
	    	.fail(function() {
				alert(data);
			}); // end ajax call
        }
	});

	//insert kit
/*	$("#kitinsert").click(function(){
		var protocol = $("#protocol").val();
		var kitname = $("#kitname").val();
		var regex_name = /^[\w()-]{1,30}$/;
		var regex = /^[0-9a-zA-Z]+$/;

		if (!kitname.match(regex_name)) {
			alert("kit명은 문자,순자,(),-만 입력가능합니다. 길이는 1~30자입니다.");
			console.log("kitname match");
		} else {
			//check if protocol is on the list
			$.post( "kitinsert.php", {protocol: protocol, kitname:kitname}, function(data) {
				//alert( "ok2" );
				var counter;
				var tr1;
				$('#kitbody').remove();
				$.each(data, function(i, item) {
					tr1 = "<tr>";
					tr1 = tr1+"<td>"+item.id+"</td>";
					tr1 = tr1+"<td>"+item.protocol_cd+"</td>";
					tr1 = tr1+"<td>"+item.kit_name+"</td>";
					tr1 = tr1+"<td>"+item.regidate+"</td>";
					tr1 = tr1+"<td>"+item.register+"</td>";
					tr1 = tr1+"<td><button type='button' class='btn btn-primary'>수정</button></td>";
					tr1 = tr1+"<td><button type='button' class='btn btn-primary'>삭제</button></td>";
					tr1 = tr1+"</tr>";
					$('#example2').append(tr1);
					$('#kitname').val('');

				    //alert(item.ptl_kit_cd);
				    counter = i;
				});
			},'json')
			.fail(function() {
				alert(data);
			}); // end ajax call					

		}
			
	});
*/
});