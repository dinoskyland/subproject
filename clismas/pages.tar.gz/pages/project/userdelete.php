<?php
//display error 
ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);

include_once '../clisconnect.php';

// prepare and bind
$stmt = $connClis->prepare("DELETE from csm01_users where user_ID=?");
$stmt->bind_param("s", $userid);
$userid = $_POST['userid'];

if ($stmt->execute() === TRUE) {
    echo '삭제되었습니다';
} else {
    echo "Error: " . $connClis->error;
}
$stmt->close();
?>
