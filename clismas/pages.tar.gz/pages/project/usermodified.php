<?php
//display error 
ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);
if (!isset($_SESSION)) {
    session_start(); // Starting Session
}

include_once '../clisconnect.php';

// prepare and bind
$stmt = $connClis->prepare("UPDATE csm01_users set site_name=?,user_name=?,user_contact=?,user_email=?,user_address=?,check_lab1=?,check_lab2=?,check_pick1=?,check_pick2=?,check_kit1=?,check_kit2=?,check_report1=?,check_report2=?,check_report3=?,regidate=?,register=? where user_ID=?");
$stmt->bind_param("sssssssssssssssss", $site, $person, $phone, $email, $address, $lab1, $lab2, $pick1, $pick2, $kit1, $kit2, $report1, $report2, $report3, $regidate, $register, $userid);

$site   = $_POST['site'];
$person   = $_POST['person'];
$phone    = $_POST['phone'];
$email    = $_POST['email'];
$address  = $_POST['address'];
$lab1     = $_POST['lab1'];
$lab2     = $_POST['lab2'];
$pick1    = $_POST['pick1'];
$pick2    = $_POST['pick2'];
$kit1     = $_POST['kit1'];
$kit2     = $_POST['kit2'];
$report1  = $_POST['report1'];
$report2  = $_POST['report2'];
$report3  = $_POST['report3'];
$regidate = date('Ymd');
if (isset($_SESSION['login_user'])) {
    $register = $_SESSION['login_user'];
} else {
    $register = 'superadmin';
}
$userid   = $_POST['userid'];

// $protocol = strip_tags($protocol);
// $userid = strip_tags($userid);
// $password = strip_tags($password); 

if ($stmt->execute() === TRUE) {
    echo '1';
} else {
    echo "Error: " . $connClis->error;
}
$stmt->close();
$connClis->close();

?>
