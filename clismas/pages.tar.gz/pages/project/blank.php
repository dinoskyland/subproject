<?php
if(!isset($_SESSION)) 
{ 
	session_start(); // Starting Session
} 
$_SESSION['page']="project/blank.php";
if(!isset($_SESSION['login_user'])){
	header('Location: ../../index.php'); // Redirecting To Home Page
}
$user=$_SESSION['login_user'];
if($_SESSION['manager'] == 't'){
	$manager='관리자';
} else {
	$manager='일반사용자';	
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>CLISMAS</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<!-- Bootstrap 3.3.6 -->
	<link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
	<!-- Select2 -->
	<link rel="stylesheet" href="../../plugins/select2/select2.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
  folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../../plugins/iCheck/flat/blue.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="../../plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="../../plugins/datepicker/datepicker3.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../plugins/datatables/dataTables.bootstrap.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="../../plugins/iCheck/all.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<!-- ADD THE CLASS layout-boxed TO GET A BOXED LAYOUT -->
<body class="hold-transition skin-blue sidebar-mini">
	<!-- Site wrapper -->
	<div class="wrapper">
		<header class="main-header">
			<!-- Logo -->
			<a href="../labresult/index.php" class="logo">
				<!-- mini logo for sidebar mini 50x50 pixels -->
				<span class="logo-mini"><b>CLISMAS</b></span>
				<!-- logo for regular state and mobile devices -->
				<span class="logo-lg"><b>CLISMAS</b></span>
			</a>
			<!-- Header Navbar: style can be found in header.less -->
			<nav class="navbar navbar-static-top">
				<!-- Sidebar toggle button-->
				<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
					<span class="sr-only">Toggle navigation</span>
				</a>

				<div class="navbar-custom-menu">
					<ul class="nav navbar-nav">

						<!-- User Account: style can be found in dropdown.less -->
						<li class="dropdown user user-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">
								<span class="hidden-xs"><?=$user?></span>
							</a>
							<ul class="dropdown-menu">
								<!-- User image -->
								<li class="user-header">
									<p>
										<?=$user?>
										<small><?=$manager?></small>
									</p>
								</li>
								<!-- Menu Footer-->
								<li class="user-footer">
									<div class="pull-left">
										<a href="#" class="btn btn-default btn-flat">Profile</a>
									</div>
									<div class="pull-right">
										<a href="../login/logout.php" class="btn btn-default btn-flat">Log out</a>
									</div>
								</li>
							</ul>
						</li>
					</ul>
				</div>
			</nav>
		</header>

		<!-- =============================================== -->

		<aside class="main-sidebar">
			<!-- sidebar: style can be found in sidebar.less -->
			<section class="sidebar">
				<!-- Sidebar user panel -->
				<!-- sidebar menu: : style can be found in sidebar.less -->
				<ul class="sidebar-menu">
					<li class="treeview">
						<a href="#">
							<i class="fa fa-flask"></i><span>Lab Result</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">
							<li><a href="../labresult/index.php"><i class="fa fa-circle-o"></i> Real Time Test Result</a></li>
							<li><a href="../labresult/statistics.php"><i class="fa fa-circle-o"></i> Result Statistics</a></li>
						</ul>
					</li>
					<li>
						<a href="../pickup/pickuprequest.php">
							<i class="fa fa-plus-square"></i><span>Pickup Request</span>
						</a>
					</li>
					<li>
						<a href="../kit/kitorder.php">
							<i class="fa fa-reorder"></i><span>Kit Order</span>
						</a>
					</li>
					<li class="treeview">
						<a href="#">
							<i class="fa fa-file-o"></i><span>Result Report</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">
							<li><a href="../report/resultreport.php"><i class="fa fa-circle-o"></i> Result Report</a></li>
							<li><a href="../report/rereport.php"><i class="fa fa-circle-o"></i> Re-Report</a></li>
							<li><a href="../report/reportlog.php"><i class="fa fa-circle-o"></i> Report Log</a></li>
						</ul>
					</li>
					<li class="treeview">
						<a href="#">
							<i class="fa fa-wrench"></i><span>Project</span>
							<span class="pull-right-container">
								<i class="fa fa-angle-left pull-right"></i>
							</span>
						</a>
						<ul class="treeview-menu">
							<li class="active"><a href="kitsetup.php"><i class="fa fa-circle-o"></i> 안건별KIT설정</a></li>
							<li><a href="../project/register.php"><i class="fa fa-circle-o"></i> 사용자등록</a></li>
							<li><a href="usermodify.php"><i class="fa fa-circle-o"></i> 사용자수정</a></li>
							<li><a href="hospitalallocate.php"><i class="fa fa-circle-o"></i> StaffSite연결</a></li>
							<li><a href="../project/confirm.php"><i class="fa fa-circle-o"></i> 사용자인증</a></li>
							<li><a href="../project/partners.php"><i class="fa fa-circle-o"></i> 업체조회</a></li>
						</ul>
					</li>
				</ul>
			</section>
			<!-- /.sidebar -->
		</aside>

		<!-- =============================================== -->

		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<!-- Main content -->
			<section class="content">
				<!-- Main row -->
				<div class="box">
					<!-- /.box-header -->
					<form class="form-horizontal checked">
						<div class="box-body">
							<p>사용 권한이 있는 페이지로 가시기 바랍니다</p>
						</div>
					</form>
				</div>
				<!-- /.box -->
			</section>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->
<!-- 		<footer class="main-footer">
			<div class="pull-right hidden-xs">
				<b>Version</b> 2.3.5
			</div>
			<strong>Copyright &copy; 2014-2016 <a href="http://almsaeedstudio.com">Almsaeed Studio</a>.</strong> All rights
			reserved.
		</footer> -->
		<div class="control-sidebar-bg"></div>
	</div>
	<!-- ./wrapper -->


	<!-- Button modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id='myModal'>
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">Order No.
						<span id='delivery_order_no', name='delivery_order_no'>
						</span>
					</h4>
				</div>
				<div class="modal-body">
					<table class="table table-bordered" id="deliverytable">
						<thead>
							<tr>								
								<th style="width: 80%">Kit명</th>
								<th>Quantity</th>
							</tr>
						</thead>
						<tbody>
							
						</tbody>
					</table>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary" id='delivered'>Save</button>
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->


	<!-- jQuery UI 1.11.4 -->
	<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script>
		$.widget.bridge('uibutton', $.ui.button);
	</script>
	<script src="../../plugins/morris/morris.min.js"></script>
	<!-- Sparkline -->
	<script src="../../plugins/sparkline/jquery.sparkline.min.js"></script>
	<!-- jvectormap -->
	<script src="../../plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="../../plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
	<!-- jQuery 2.2.4 -->
	<script src="http://code.jquery.com/jquery-2.2.4.min.js" ></script>
	<!-- Bootstrap 3.3.6 -->
	<script src="../../bootstrap/js/bootstrap.min.js"></script>
	<!-- Select2 -->
	<script src="../../plugins/select2/select2.full.min.js"></script>
	<!-- bootstrap datepicker -->
	<script src="../../plugins/datepicker/bootstrap-datepicker.js"></script>
	<script src="../../plugins/datepicker/locales/bootstrap-datepicker.kr.js"></script>
	<!-- SlimScroll 1.3.0 -->
	<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
	<!-- iCheck 1.0.1 -->
	<script src="../../plugins/iCheck/icheck.min.js"></script>
	<!-- FastClick -->
	<script src="../../plugins/fastclick/fastclick.js"></script>
	<!-- AdminLTE App -->
	<script src="../../dist/js/app.min.js"></script>
	<!-- DataTables -->
	<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
	
	<script type="text/javascript" src="kitorder.js"></script>

	<!-- Page script -->
	<script>
		$(function () {
    	//Initialize Select2 Elements
    	$('#myModal').modal({
    		show: false
    	});

    	$(".select2").select2();

	    //Date picker
	    $('#datepicker').datepicker({
	    	language: 'kr',
	    	format: 'yyyy-mm-dd',
	    	autoclose: true
	    });

	    $('.datepicker2').datepicker({
	    	language: 'kr',
	    	format: 'yyyy-mm-dd',
	    	autoclose: true
	    });

	    $('#example2').DataTable({
	    	"paging": true,
	    	"lengthChange": false,
	    	"searching": false,
	    	"ordering": true,
	    	"info": true,
	    	"autoWidth": false
	    });
	});
</script>
</body>
</html>
