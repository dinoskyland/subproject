<?php
//display error 
ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);
include_once '../clisconnect.php';

if (isset($_POST['kitinsert'])) {
	$protocol = $_POST['protocol'];
	$kitname = $_POST['kitname'];
	$date = date("Ymd");
	$register = $_SESSION['login_user'];
	$pattern = '/^[ㄱ-ㅎㅏ-ㅣ가-힣\s\w()-]+$/';

	if (preg_match($pattern, $kitname)) {
	echo $kitname;
		//insert kit
		$sql = "INSERT INTO csm04_protocol_KIT (protocol_cd,kit_name,regidate,register) VALUES ('$protocol','$kitname','$date','$register')";

		if ($connClis->query($sql) === TRUE) {
		    // echo "1";
		} else {
		    echo "Error: " . $sql . "<br>" . $connClis->error;
		}

	} else {
		$message = "Kit Name은 문자,순자,(),-,_ 만 가능합니다";
		echo "<script type='text/javascript'>alert('$message');</script>";
	}

}

if (isset($_POST['search']) || isset($_POST['kitinsert'])) {
	$protocol = $_POST['protocol'];

	//select kit
	$sql = "SELECT * FROM csm04_protocol_KIT where protocol_cd='$protocol'";
	$result = $connClis->query($sql);
	if ($result->num_rows > 0) {
	// output data of each row
		while($row = $result->fetch_assoc()) {
		//echo "<tr>";
            //echo "<tr>";
            echo "<tr>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td>" . $row["protocol_cd"] . "</td>";
            echo "<td><input type='text' class='form-control' id='" . $row["id"]."' value='" . $row["kit_name"] . "'></td>";
            echo "<td>" . $row["regidate"] . "</td>";
            echo "<td>" . $row["register"] . "</td>";
			echo "<td><button type='button' class='btn btn-primary kitmodify' id='".$row["id"]."'>수정</button></td>";
			echo "<td><button type='button' class='btn btn-primary kitdelete' id='".$row["id"]."'>삭제</button></td>";
            echo "</tr>";
		}		
	} else {
		echo "0 results";
	}
}
?>
