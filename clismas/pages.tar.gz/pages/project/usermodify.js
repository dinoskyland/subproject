// Bind to the submit event of our form
$(function() {

	$("#submit").click(function(){
		//alert($('#protocolname').text());
		if ($('#protocolname').text() != '') {
				var site = $("#site").val();
				var userid = $("#userid").val();
				var person = $("#person").val();
				var phone = $("#phone").val();
				var email = $("#email").val();
				var address = $("#address").val();
				var lab1 = $("#lab1").prop('checked');
				var lab2 = $("#lab2").prop('checked');
				var pick1 = $("#pick1").prop('checked');
				var pick2 = $("#pick2").prop('checked');
				var kit1 = $("#kit1").prop('checked');
				var kit2 = $("#kit2").prop('checked');
				var report1 = $("#report1").prop('checked');
				var report2 = $("#report2").prop('checked');
				var report3 = $("#report3").prop('checked');

				var pattern = /^[0-9a-zA-Z]{1,10}$/;
				var pattern_loose = /^[ㄱ-ㅎㅏ-ㅣ가-힣\s\w-()]+$/;
				var pattern_email = /^[@.\s\w-()]+$/;
				//var pattern = /^[0-9a-zA-Z]{6,10}+$/;

				// if ($("#lab2").prop('checked')) {
				// 	alert("Result Statistics");
				// } 

				if (!person.match(pattern_loose) && person.length!=0) {
					alert("담당자명은 문자, 순자, (), -, _ 만 가능합니다");
				} else if (!phone.match(pattern_loose) && phone.length!=0) {
					alert("연락처는 문자, 순자, (), -, _ 만 가능합니다");
				} else if (!email.match(pattern_email) && email.length!=0) {
					alert("이메일은연락처는 문자, 순자, @, . 만 가능합니다");
				} else if (!address.match(pattern_loose) && address.length!=0) {
					alert("주소는 문자, 순자, (), -, _ 만 가능합니다");
				} else {
					$.post("usermodified.php", {
						site: site,
						userid: userid,
						person: person,
						phone: phone,
						email: email,
						address: address,
						lab1: lab1,
						lab2: lab2,
						pick1: pick1,
						pick2: pick2,
						kit1: kit1,
						kit2: kit2,
						report1: report1,
						report2: report2,
						report3: report3
					}, function(data) {
						if (data == '1') {
							alert('수정되었습니다');
							//window.location.href = "../login/index.php";
							window.location.href = "usermodify.php";
							//location.reload();

						}
					})
					.fail(function() {
						//alert( "안건코드 입력확인" );
						alert("error" );
					}); // end ajax call   		
				}

		} else {
			alert('id search를 먼저 해주세요');	
		}
	});

	$("#submit2").click(function(){
		//alert($('#protocolname').text());
		if ($('#staffperson').val() != '') {
				var staffperson = $("#staffperson").val();
				var staffphone = $("#staffphone").val();
				var staffrole = $("#staffrole").val();

				var pattern = /^[0-9a-zA-Z]{1,10}$/;
				var pattern_loose = /^[ㄱ-ㅎㅏ-ㅣ가-힣\s\w-()]+$/;
				var pattern_email = /^[@.\s\w-()]+$/;
				//var pattern = /^[0-9a-zA-Z]{6,10}+$/;

				// if ($("#lab2").prop('checked')) {
				// 	alert("Result Statistics");
				// } 

				if (!staffperson.match(pattern_loose) && person.length!=0) {
					alert("담당자명은 문자, 순자, (), -, _ 만 가능합니다");
				} else if (!staffphone.match(pattern_loose) && phone.length!=0) {
					alert("연락처는 문자, 순자, (), -, _ 만 가능합니다");
				} else {
					$.post("staffmodified.php", {
						staffperson: staffperson,
						staffphone: staffphone,
						staffrole: staffrole
					}, function(data) {
							alert(data);
							//window.location.href = "../login/index.php";
							window.location.href = "usermodify.php";
							//location.reload();

					})
					.fail(function() {
						//alert( "안건코드 입력확인" );
						alert("error" );
					}); // end ajax call   		
				}

		} else {
			alert('id search를 먼저 해주세요');	
		}
	});

	$("#userdelete").click(function(){
		var userid = $("#userid").val();
		$.post("userdelete.php", {
			userid: userid
		}, function(data) {
			alert(data);
			window.location.href = "usermodify.php";
		})
		.fail(function() {
			//alert( "안건코드 입력확인" );
			alert(data);
		}); // end ajax call   		
	});

	$("#staffdelete").click(function(){
		$.post("staffdelete.php", function(data) {
			alert(data);
			window.location.href = "usermodify.php";
		})
		.fail(function() {
			//alert( "안건코드 입력확인" );
			alert(data);
		}); // end ajax call   		
	});


});