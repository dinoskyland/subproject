<?php			
//display error 
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
include_once '../clisconnect.php';
if(!isset($_SESSION)) { 
	session_start(); // Starting Session
} 

if(isset($_SESSION['usermodify'])) { 
	$userid=$_SESSION['usermodify']; //set the value of select as the one being modified
} else {
	$userid='';	
}


$sql = "SELECT DISTINCT manager_name, mobile, user_ID, role FROM csm03_spl_pickup_request_staff where user_PW!=''";

$result = $connClis->query($sql);

if ($result->num_rows > 0) {
// output data of each row
	while($row = $result->fetch_assoc()) {
		// echo $row['pl_protocol_cd'];
		if ($row['user_ID'] == $userid) {
			echo "<option selected='selected'>{$row['manager_name']}/{$row['mobile']}/{$row['role']}/{$row['user_ID']}</option>";		
		} else {
			echo "<option>{$row['manager_name']}/{$row['mobile']}/{$row['role']}/{$row['user_ID']}</option>";		
		}

					
	}
} else {
	//echo "0 results";
}


?>
