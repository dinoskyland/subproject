<?php			
//display error 
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
include_once '../clisconnect.php';
if(!isset($_SESSION)) { 
	session_start(); // Starting Session
} 

if(isset($_SESSION['usermodify'])) { 
	$userid=$_SESSION['usermodify']; //set the value of select as the one being modified
} else {
	$userid='';	
}

$sql = "SELECT * FROM csm01_users where manager_checked='f'";

$result = $connClis->query($sql);

if ($result->num_rows > 0) {
// output data of each row
	while($row = $result->fetch_assoc()) {
		// echo $row['user_ID'];
		if ($row['user_ID'] == $userid) {
			echo "<option selected='selected'>{$row['user_ID']}</option>";	
		} else {
			echo "<option>{$row['user_ID']}</option>";						
		}
	}		
} else {
	echo "0 results";
}
//manager

//$connClis->close();

?>
