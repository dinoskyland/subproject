// Bind to the submit event of our form
$(function() {
	//protocol search
/*	$("#search").click(function(){
		var protocol = $("#protocol").val();

		$.post( "../protocolsearch.php", {protocol: protocol}, function(data) {
			// var json = $.parseJSON(data);
		   //  		alert(json.result[0].pl_protocol_name);
		   $("#protocolname").val(data[0].pl_protocol_name);
		   $("#period").val(data[0].pl_study_begin+' ~ '+data[0].pl_study_end);
		   $("#sponsor").val(data[0].pl_sponser_name);
		   $("#info").val('대표PI: '+data[0].pl_PI_name+'\n'+'대상질병: '+data[0].pl_diseases+'\n'+'견적비용: '+data[0].pl_estimate_cost);
		   //alert(data);
		},'json')
		.fail(function() {
			alert( "안건코드 입력확인" );
		}); // end ajax call		
	});

	$("#kitinsert").click(function(){
			alert( "안건코드 입력확인" );
	});
*/

	$('.pickup-group').hide();

	$('#pickup').change(function() {
        if(this.checked) {
            //alert("Are you sure? change");
            console.log($(this).prop('value'));
            $('#manager').prop('checked',false);
            $('.manager-group').hide();
            $('.user-group').hide();
            $('.pickup-group').show();
        } else {
            $('.pickup-group').hide();
            $('.manager-group').hide();
            $('.user-group').show();
        }
    });

	$('#manager').change(function() {
        if(this.checked) {
            //alert("Are you sure? change");
            $('#pickup').prop('checked',false);
            $('.user-group').hide();
            $('.pickup-group').hide();
            $('.manager-group').show();
        } else {
            $('.manager-group').hide();
            $('.pickup-group').hide();
            $('.user-group').show();
        }
    });

	$("#submit").click(function(){
		if ($('#pickup').is(':checked')) {
			//for pickup staff
			var userid = $("#userid").val();
			var password = $("#password").val();
			var person = $("#person").val();
			var phone = $("#phone").val();
			var role = $("#role").val();

			var taken = $("#taken").prop('value');
			var confirm = $("#confirm").val();
			var pattern = /^[0-9a-zA-Z]{1,10}$/;
			var pattern_loose = /^[ㄱ-ㅎㅏ-ㅣ가-힣\s\w-()]+$/;
			//var pattern = /^[0-9a-zA-Z]{6,10}+$/;

			// if ($("#lab2").prop('checked')) {
			// 	alert("Result Statistics");
			// } 

			if (userid.length == 0) {
				alert("아이디를 입력하세요");
			} else if (password.length == 0) {
				alert("패스워드를 입력하세요");
			} else if (confirm.length == 0) {
				alert("패스워드확인을 입력하세요");
			} else if (taken == 'taken') {
				alert("아이디 중복 확인을 해주세요");
			} else if (!userid.match(pattern)) {
				alert("User ID는 1~10자리, 문자, 순자만 가능합니다");
			} else if (!password.match(pattern)) {
				alert("비밀번호는 1~10자리, 문자, 순자만 가능합니다");
			} else if (!person.match(pattern_loose) && person.length!=0) {
				alert("담당자명은 문자, 순자, (), -, _ 만 가능합니다");
			} else if (!phone.match(pattern_loose) && phone.length!=0) {
				alert("연락처는 문자, 순자, (), -, _ 만 가능합니다");
			} else if (password != confirm) {
				alert("패스워드가 일치하지 않습니다");
			} else {
				$.post("createstaff.php", {
					userid: userid,
					password: password,
					person: person,
					phone: phone,
					role: role
				}, function(data) {
					if (data == '1') {
						alert('등록되었습니다');
						//window.location.href = "../login/index.php";
						window.location.href = "register.php";
						//location.reload();

					}
				})
				.fail(function() {
					//alert( "안건코드 입력확인" );
					alert("error" );
				}); // end ajax call   		
			}

		} else { // for users or managers
			var protocol = $("#protocol").val();
			var protocolname = $("#protocolname").text();
			var userid = $("#userid").val();
			var manager = $("#manager").prop('checked');
			var password = $("#password").val();
			var site = $("#site").val();
			var person = $("#person").val();
			var phone = $("#phone").val();
			var email = $("#email").val();
			var address = $("#address").val();
			var lab1 = $("#lab1").prop('checked');
			var lab2 = $("#lab2").prop('checked');
			var pick1 = $("#pick1").prop('checked');
			var pick2 = $("#pick2").prop('checked');
			var kit1 = $("#kit1").prop('checked');
			var kit2 = $("#kit2").prop('checked');
			var report1 = $("#report1").prop('checked');
			var report2 = $("#report2").prop('checked');
			var report3 = $("#report3").prop('checked');

			var taken = $("#taken").prop('value');
			var confirm = $("#confirm").val();
			var pattern = /^[0-9a-zA-Z]{1,10}$/;
			var pattern_loose = /^[ㄱ-ㅎㅏ-ㅣ가-힣\s\w-()]+$/;
			var pattern_email = /^[@.\s\w-()]+$/;
			//var pattern = /^[0-9a-zA-Z]{6,10}+$/;

			// if ($("#lab2").prop('checked')) {
			// 	alert("Result Statistics");
			// } 

			console.log(protocolname);
			console.log(protocol);
			if (userid.length == 0) {
				alert("아이디를 입력하세요");
			} else if (password.length == 0) {
				alert("패스워드를 입력하세요");
			} else if (confirm.length == 0) {
				alert("패스워드확인을 입력하세요");
			} else if (taken == 'taken') {
				alert("아이디 중복 확인을 해주세요");
			} else if (!userid.match(pattern)) {
				alert("User ID는 1~10자리, 문자, 순자만 가능합니다");
			} else if (!password.match(pattern)) {
				alert("비밀번호는 1~10자리, 문자, 순자만 가능합니다");
			} else if (!site.match(pattern_loose) && site.length!=0) {
				alert("Site명은 문자, 순자, (), -, _ 만 가능합니다");
			} else if (!person.match(pattern_loose) && person.length!=0) {
				alert("담당자명은 문자, 순자, (), -, _ 만 가능합니다");
			} else if (!phone.match(pattern_loose) && phone.length!=0) {
				alert("연락처는 문자, 순자, (), -, _ 만 가능합니다");
			} else if (!email.match(pattern_email) && email.length!=0) {
				alert("이메일은연락처는 문자, 순자, @, . 만 가능합니다");
			} else if (!address.match(pattern_loose) && address.length!=0) {
				alert("주소는 문자, 순자, (), -, _ 만 가능합니다");
			} else if (password != confirm) {
				alert("패스워드가 일치하지 않습니다");
			} else {
				$.post("createuser.php", {
					protocol: protocol,
					protocolname: protocolname,
					userid: userid,
					manager: manager,
					password: password,
					site: site,
					person: person,
					phone: phone,
					email: email,
					address: address,
					lab1: lab1,
					lab2: lab2,
					pick1: pick1,
					pick2: pick2,
					kit1: kit1,
					kit2: kit2,
					report1: report1,
					report2: report2,
					report3: report3
				}, function(data) {
					if (data == '1') {
						alert('등록되었습니다');
						//window.location.href = "../login/index.php";
						window.location.href = "register.php";
						//location.reload();

					}
				})
				.fail(function() {
					//alert( "안건코드 입력확인" );
					alert("error" );
				}); // end ajax call   		
			}

		}
	});


	//id is already taken?
	$("#taken").click(function(){
		var userid = $("#userid").val();
		var pattern = /^[0-9a-zA-Z]{1,10}$/;

		if (userid == '') {
			alert("Please fill id field...!!!!!!");
		} else if (!userid.match(pattern)) {
			alert("아이디는 1~10자리, 문자, 순자만 가능합니다");
		} else {
			if ($('#pickup').is(':checked')) { //for pickup staff
				$.post("confirmPickupStaff.php", { //for users
					userid: userid,
				}, function(data) {
					if (data == 1) {
						alert("이미 사용중인 아이디입니다" );
						$("#taken").prop('value', 'taken');
							//$("#userid").prop('name', 'unconfirmed');
					} else {
						alert("사용 가능 아이디");
						$("#taken").prop('value', 'usalble');
						//$("#userid").prop('name', 'confirmed');
						//console.log($("#taken").prop('value'));
					}
				})
				.fail(function() {
					alert("error");
				}); // end ajax call   						

			} else {
				$.post("confirm.php", { //for users
					userid: userid,
				}, function(data) {
					if (data == 1) {
						alert("이미 사용중인 아이디입니다" );
						$("#taken").prop('value', 'taken');
							//$("#userid").prop('name', 'unconfirmed');
					} else {
						alert("사용 가능 아이디");
						$("#taken").prop('value', 'usalble');
						//$("#userid").prop('name', 'confirmed');
						//console.log($("#taken").prop('value'));
					}
				})
				.fail(function() {
					alert("error");
				}); // end ajax call   						
			}

		}
	});

	//userid is modified
	$("#userid").keyup(function(){
		//$("#userid").prop('name', 'unconfirmed');
		$("#taken").prop('value', 'taken');
	});

	//insert kit
/*	$("#kitinsert").click(function(){
		var protocol = $("#protocol").val();
		var kitname = $("#kitname").val();
		var pattern_name = /^[\w()-]{1,30}$/;
		var pattern = /^[0-9a-zA-Z]+$/;

		if (!kitname.match(pattern_name)) {
			alert("kit명은 문자,순자,(),-만 입력가능합니다. 길이는 1~30자입니다.");
			console.log("kitname match");
		} else {
			//check if protocol is on the list
			$.post( "kitinsert.php", {protocol: protocol, kitname:kitname}, function(data) {
				//alert( "ok2" );
				var counter;
				var tr1;
				$('#kitbody').remove();
				$.each(data, function(i, item) {
					tr1 = "<tr>";
					tr1 = tr1+"<td>"+item.id+"</td>";
					tr1 = tr1+"<td>"+item.protocol_cd+"</td>";
					tr1 = tr1+"<td>"+item.kit_name+"</td>";
					tr1 = tr1+"<td>"+item.regidate+"</td>";
					tr1 = tr1+"<td>"+item.register+"</td>";
					tr1 = tr1+"<td><button type='button' class='btn btn-primary'>수정</button></td>";
					tr1 = tr1+"<td><button type='button' class='btn btn-primary'>삭제</button></td>";
					tr1 = tr1+"</tr>";
					$('#example2').append(tr1);
					$('#kitname').val('');

				    //alert(item.ptl_kit_cd);
				    counter = i;
				});
			},'json')
			.fail(function() {
				alert(data);
			}); // end ajax call					

		}
			
	});
*/
});