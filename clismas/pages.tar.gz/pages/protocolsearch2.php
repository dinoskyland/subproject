<?php			
//display error 
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
include_once 'limsconnect.php';
if(!isset($_SESSION)) { 
	session_start(); // Starting Session
} 

if ($_SESSION['manager'] == 't') {
		//$protocolname='';
		$period='';
		$info='';
		$sponsor='';
	if (isset($_POST['search']) || isset($_POST['kitinsert'])) {
		//when protocolsearch button is hit or kitinsert button from kitinsert.php is hit
		$protocol = $_POST['protocol'];
		$_SESSION['protocol']=$protocol;
		$_SESSION['site']='';

		//echo $protocol;
		$sql = "SELECT pl_protocol_cd,pl_protocol_name,pl_study_begin,pl_study_end,pl_sponser_name,pl_PI_name,pl_diseases,pl_estimate_cost FROM bim07_protocolbase WHERE pl_protocol_cd='$protocol'";

		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
		// output data of each row
			while($row = $result->fetch_assoc()) {
			//echo "<tr>";
				$_SESSION['protocolname']=$row["pl_protocol_name"];
				$protocolname=$_SESSION['protocolname'];
				$period=$row["pl_study_begin"].' ~ '.$row["pl_study_end"];
				$info="대표PI: ".$row["pl_PI_name"]."\n"."대상질병: ".$row["pl_diseases"]."\n"."견적비용: ".$row["pl_estimate_cost"];
				$sponsor=$row["pl_sponser_name"];
			}		
		} else {
			echo "0 results";
		}
	}
} else {
	// when an user hits a protocolsearch button

}


?>