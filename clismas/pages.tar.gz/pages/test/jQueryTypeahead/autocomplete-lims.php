<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
ini_set('display_startup_errors', 1);

if (isset($_REQUEST['query'])) {
    $query = $_GET['query'];
    
    if ($_SERVER['SERVER_NAME'] == "localhost") {
        $servername = "112.148.73.107";
    } else {
        $servername = "localhost";
    }
    $username = "lims";
    $password = "lims0001";
    $dbname   = "lims";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $sql = "SELECT pl_protocol_cd, pl_protocol_name FROM bim07_protocolbase WHERE pl_protocol_cd LIKE '%{$query}%' OR pl_protocol_name LIKE '%{$query}%'";
    //$sql    = "SELECT pl_protocol_cd, pl_protocol_name FROM bim07_protocolbase WHERE pl_protocol_cd LIKE '%{$query}%'";
    $result = $conn->query($sql);
    
    $array = array();
    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            $array[] = array(
                // 'label' => $row['pl_protocol_name'],
                'value' => $row['pl_protocol_cd']
            );        
        }
    } else {
        echo "0 results";
    }
    //RETURN JSON ARRAY
    echo json_encode($array);
    $conn->close();
}
?>