<?php
//display error 
error_reporting(E_ALL);
ini_set("display_errors", 1);
ini_set('display_startup_errors', 1);

$servername = "112.148.73.107";
$db_username = "clismas";
$db_password = "clis0001";
$dbname = "clismas";

// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 

session_start();// Starting Session
// Storing Session
$user_check=$_SESSION['login_user'];

// SQL Query To Fetch Complete Information Of User
$sql = "SELECT user_ID FROM csm01_users WHERE user_ID=$user_check";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
// output data of each row
	while($row = $result->fetch_assoc()) {
		$login_session =$row['user_ID'];
		if(!isset($login_session)){
			$conn->close();
			header('Location: index.php'); // Redirecting To Home Page
		}
	}
} else {
	echo "0 results";
}
$conn->close();

?>