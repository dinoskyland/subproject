<?php
//display error 
error_reporting(E_ALL);
ini_set("display_errors", 1);
ini_set('display_startup_errors', 1);

session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
	if (empty($_POST['username']) || empty($_POST['password'])) {
		$error = "Username or Password is invalid";
	} else {
		// Define $username and $password
		$username=$_POST['username'];
		$password=$_POST['password'];


		$servername = "112.148.73.107";
		$db_username = "clismas";
		$db_password = "clis0001";
		$dbname = "clismas";

		// Create connection
		$conn = new mysqli($servername, $db_username, $db_password, $dbname);

		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		// To protect MySQL injection for Security purpose
		$username = stripslashes($username);
		$password = stripslashes($password);
		$username = $conn->real_escape_string($username);
		$password = $conn->real_escape_string($password);

		$sql = "SELECT * FROM csm01_users where user_PW=$password AND user_ID=$username";
		//$sql = "SELECT * FROM csm01_users WHERE user_PW=6 AND user_ID=6";
		$result = $conn->query($sql);

		if ($result->num_rows == 1) {
    // output data of each row
			while($row = $result->fetch_assoc()) {
				echo "user_ID: " . $row["user_ID"]. " - user_PW: " . $row["user_PW"]. "<br>";
				$_SESSION['login_user']=$row["user_ID"]; // Initializing Session
				header("location: index.php"); // Redirecting To Other Page
			}
		} else {
			$error = "Username or Password is invalid"; //0 results or >1
		}

	$conn->close();
	}
}
?>