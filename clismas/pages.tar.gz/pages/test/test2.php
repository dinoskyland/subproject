<?php
// application library 1
namespace lims\pages\test;

const MYCONST = 'Lims\Pages\Test\Test';

function MyFunction() {
	return __FUNCTION__;
}

class test2 {
	static function WhoAmI() {
		return __METHOD__ .  '   ' .  __NAMESPACE__;;
	}
}
?>