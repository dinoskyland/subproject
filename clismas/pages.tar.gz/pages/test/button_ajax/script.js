 $("#button-set").click(function(){

	var values = $(this).serialize();
    $.post( "script.php", values, function(data) {
                    alert(data);
                    $("p").text(data);
	});

});

/*
<script type="text/javascript">
    $(document).ready(function(){
        $("#button-set").click(function(){
            $.ajax({
                type: 'POST',
                url: 'script.php',
                success: function(data) {
                    alert(data);
                    $("p").text(data);

                }
            });
   		});
	});
</script>
*/