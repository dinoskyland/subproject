

<!DOCTYPE html>
<html>
<head>
	<title>PHP: Get Values of Multiple Checked Checkboxes</title>
	<link rel="stylesheet" href="php_checkbox.css" />
</head>
<body>
	<div class="container">
		<div class="main">
			<h2>PHP: Get Values of Multiple Checked Checkboxes</h2>






<form action="#" method="post">
<input type="checkbox" name="gender" value="Male">Male</input>
<input type="checkbox" name="gender" value="Female">Female</input>
<input type="submit" name="submit" value="Submit"/>
</form>
<?php
if (isset($_POST['gender'])){
echo $_POST['gender']; // Displays value of checked checkbox.
}
?>





		</div>
	</div>
</body>
</html>

