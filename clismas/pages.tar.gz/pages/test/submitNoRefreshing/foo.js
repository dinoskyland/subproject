// Bind to the submit event of our form
$(".foo").submit(function(event){

	/* Get from elements values */
	event.preventDefault();
	var values = $(this).serialize();

	$.post( "submit.php",values, function(data) {
		alert( data );
	})
	.fail(function() {
		alert( "error" );
	})
});


