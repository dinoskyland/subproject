<?php
$bar = isset($_POST['bar']) ? $_POST['bar'] : null;
 $fname = $bar;
echo "hello this is one  " . $fname;
echo "right?";
?>

