    <?php
$regidate      = date("Y-m-d h:ia");

    echo $regidate;
