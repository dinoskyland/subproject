

<?php
$name=$_POST['name1']; // Fetching Values from URL.
$password= $_POST['password1']; // Password Encryption, If you like you can also echo "This email is already registered, Please try another email...";
echo $name. "   ". $password."good";
?>

