<?php
//display error 
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
if (!isset($_SESSION)) {
    session_start(); // Starting Session
}
include_once 'clisconnect.php';

if ($_SESSION['manager'] == 't') {
    $phone = '';
    
    if (isset($_POST['searchRequester']) && isset($_POST['site'])) {
        //when protocolsearch button is hit or kitinsert button from kitinsert.php is hit
        $site             = $_POST['site'];
        $_SESSION['site'] = $site;
        $protocol = $_SESSION['protocol'];
      
        //echo $protocol;
        $sql = "SELECT user_name,user_contact FROM csm01_users WHERE protocol_cd='$protocol' and site_name='$site'";
        
        $result = $connClis->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                //echo "<tr>";
                $phone = $row["user_contact"];
            }
            $_SESSION['phone']=$phone;
        } else {
            $_SESSION['phone']='';
            //echo "0 results";
        }
    }
} else {
    // when an user hits a protocolsearch button
    
}

?>