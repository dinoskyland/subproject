<?php			
	//display error 
	error_reporting(E_ALL);
	ini_set("display_errors", 1);
	ini_set('display_startup_errors', 1);
	include_once '../clisconnect.php';

	if(isset($_POST['submit'])) { 
		$sql = "SELECT sp_cd,sp_name,protocol_name,site_name,user_ID,user_PW,user_name,user_contact,user_email,user_address FROM csm01_users";

		$result = $conn->query($sql);
		
		if ($result->num_rows > 0) {
		    // output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<tr>";
				echo "<td>".$row["sp_cd"]."</td>";
				echo "<td>".$row["sp_name"]."</td>";
				echo "<td>".$row["protocol_name"]."</td>";
				echo "<td>".$row["site_name"]."</td>";
				echo "<td>".$row["user_ID"]."</td>";
				echo "<td>".$row["user_PW"]."</td>";
				echo "<td>".$row["user_name"]."</td>";
				echo "<td>".$row["user_contact"]."</td>";
				echo "<td><button type=\"button\" class=\"btn btn-info button-send\" id=".$row["user_ID"].">Send</button></td>";
				echo "<td><a href=\"openpdf.php?file=Clismas.pdf\">pdf</a></td>";
				echo "</tr>";
			}
		} else {
		echo "0 results";
		}
		$conn->close();
	}
?>
