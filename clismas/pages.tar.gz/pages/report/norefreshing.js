// Bind to the submit event of our form
$(function() {
	$(".button-send").click(function(){
    	var values = $(this).attr("id");
    	$.post( "buttonsend.php", {id: values}, function(data) {
    		alert(data);
    	})
    	.fail(function() {
			alert( "error" );
		}); // end ajax call
	});
});