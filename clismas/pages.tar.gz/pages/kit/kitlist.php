<?php
//display error 
ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);
if(!isset($_SESSION)) 
{ 
	session_start(); // Starting Session
} 
include_once '../clisconnect.php';

$protocol = $_SESSION['protocol'];

$sql = "SELECT id,kit_name FROM csm04_protocol_KIT where protocol_cd='$protocol'";
$result = $connClis->query($sql);
if ($result->num_rows > 0) {
// output data of each row
	while($row = $result->fetch_assoc()) {
	//echo "<tr>";
        //echo "<tr>";
        echo "<tr>";
        echo "<td><span class='kitname' id='".$row["id"]."'>" . $row["kit_name"] . "</span></td>";
        echo "<td><input type='text' class='form-control kitquantity'></td>";
        echo "</tr>";
	}		
} else {
	echo "0 results";
}

/*if (isset($_POST['search'])) {
	$protocol = $_POST['protocol'];

	$sql = "SELECT id,kit_name FROM csm04_protocol_KIT where protocol_cd='$protocol'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
	// output data of each row
		while($row = $result->fetch_assoc()) {
		//echo "<tr>";
	        //echo "<tr>";
	        echo "<tr>";
	        echo "<td><span class='kitname' id='".$row["id"]."'>" . $row["kit_name"] . "</span></td>";
            echo "<td><input type='text' class='form-control kitquantity'></td>";
	        echo "</tr>";
		}		
	} else {
		echo "0 results";
	}
}
*/
/*if (isset($_POST['order'])) {
	$protocol = $_POST['protocol'];
	$protocolname = $_POST['protocolname'];
	$site = $_POST['site'];
	$address = $_POST['address'];
	$phone = $_POST['phone'];
	$requester = $_POST['requester'];
	$datepicker = $_POST['datepicker'];
	$pattern = '/^[\w()-@]+$/';

	$order_no = date("Ymd");
	$sql = "SELECT * FROM csm04_KIT_order where order_no='$order_no'";
	$result = $conn->query($sql);

	
	if ($result->num_rows > 0) {
		$num_rows = mysql_num_rows($result);
		$order_no = date("Ymd") . ($num_rows+1);

	// output data of each row
	} else {
		$order_no = date("Ymd") . 1;
		//echo $order_no;
	}


	if (!preg_match($pattern, $protocolname)) {
		$message = "안건명은 문자,순자,(),-,_ 만 가능합니다";
		echo "<script type='text/javascript'>alert('$message');</script>";
	} else if (!preg_match($pattern, $site)) {
		$message = "Site명은 문자,순자,(),-,_ 만 가능합니다";
		echo "<script type='text/javascript'>alert('$message');</script>";
	} else if (!preg_match($pattern, $address)) {
		$message = "Kit Name은 문자,순자,(),-,_ 만 가능합니다";
		echo "<script type='text/javascript'>alert('$message');</script>";

	} else if (!preg_match($pattern, $phone)) {
		$message = "Kit Name은 순자,(),- 만 가능합니다";
		echo "<script type='text/javascript'>alert('$message');</script>";

	} else if (!preg_match($pattern, $requester)) {
		$message = "Kit Name은 문자,순자만 가능합니다";
		echo "<script type='text/javascript'>alert('$message');</script>";

	} else {
		//insert kit
		$sql = "INSERT INTO csm04_KIT_order (order_no,protocol_cd,protocol_name,site_name,shipping_addr,contact_no,requester,desired_date,order_sum) VALUES ('$order_no','$protocol','$protocolname','$site','$address',$phone','$requester','$datepicker','$')";

		if ($conn->query($sql) === TRUE) {
		    // echo "1";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

	}
}*/

?>
