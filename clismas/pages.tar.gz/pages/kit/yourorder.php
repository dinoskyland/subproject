<?php
//display error 
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
include_once '../clisconnect.php';
if(!isset($_SESSION)) 
{ 
    session_start(); // Starting Session
} 

//if (isset($_POST['search'])) {
    $protocol = $_SESSION['protocol'];
    $sql = "SELECT * FROM csm04_KIT_order where protocol_cd='$protocol'";
    
    $result = $connClis->query($sql);    
    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["order_no"] . "</td>";
            echo "<td>" . $row["site_name"] . "</td>";
            echo "<td>" . $row["request_date"] . "</td>";
            echo "<td>" . $row["requester"] . "</td>";
            echo "<td>" . $row["desired_date"] . "</td>";
            echo "<td>" . $row["order_sum"] . "</td>";
            if ($_SESSION['manager'] == 't') {
                if ($row['status'] == 'requested') {
                    echo "<td><input type='text' class='form-control kitquantity' id='expiration' style='width: 100%' value='".$row["expired_date"]."'></td>"; //expiration date
                    echo "<td><button type='button' data-toggle='modal' data-target='#myModal' class='btn btn-primary button-set' id='" . $row["order_no"] . "' name='".$row["order_sum"]."'>Set</button></td>"; //shipped date
                    echo "<td>{$row['received_date']}</td>"; //received date                
                    echo "<td>{$row['status']}</td>"; //status
                    echo "<td><div class='checkbox'><input type='checkbox' class='checkbox_cancel' id='" . $row["order_no"] . "'></div></td>";             
                } else if ($row['status'] == 'shipped') {
                    echo "<td>{$row["expired_date"]}</td>"; //expiration date
                    echo "<td>{$row["senddate"]}</td>"; //shipped date
                    echo "<td><button type='button' class='btn btn-primary button-received' id='" . $row["order_no"] . "'>Received</button></td>"; //received date
                    echo "<td>{$row['status']}</td>"; //status
                    echo "<td><div class='checkbox'><input type='checkbox' disabled></div></td>"; //cancel order            

                } else if ($row['status'] == 'received') {
                    echo "<td>{$row["expired_date"]}</td>"; //expiration date
                    echo "<td>{$row["senddate"]}</td>"; //shipped date
                    echo "<td>{$row["received_date"]}</td>"; //shipped date
                    echo "<td>{$row['status']}</td>"; //status
                    echo "<td><div class='checkbox'><input type='checkbox' disabled></div></td>"; //cancel order            

                } else { //canceled
                    echo "<td>{$row["expired_date"]}</td>"; //expiration date
                    echo "<td>{$row["senddate"]}</td>"; //shipped date
                    echo "<td>{$row["received_date"]}</td>"; //shipped date
                    echo "<td>{$row['status']}</td>"; //status
                    echo "<td><div class='checkbox'><input type='checkbox' disabled></div></td>"; //cancel order            

                }
                echo "</tr>";

            } else { //user
                if ($row['status'] == 'requested') {
                        echo "<td>{$row["expired_date"]}</td>"; //expiration date
                        echo "<td>{$row["senddate"]}</td>"; //shipped date
                        echo "<td>{$row['received_date']}</td>"; //received date                
                        echo "<td>{$row['status']}</td>"; //status
                        echo "<td><div class='checkbox'><input type='checkbox' class='checkbox_cancel' id='" . $row["order_no"] . "'></div></td>";             
                } else if ($row['status'] == 'shipped') {
                    echo "<td>{$row["expired_date"]}</td>"; //expiration date
                    echo "<td>{$row["senddate"]}</td>"; //shipped date
                    echo "<td><button type='button' class='btn btn-primary button-received' id='" . $row["order_no"] . "'>Received</button></td>"; //received date
                    echo "<td>{$row['status']}</td>"; //status
                    echo "<td><div class='checkbox'><input type='checkbox' disabled></div></td>"; //cancel order            

                } else if ($row['status'] == 'received') {
                    echo "<td>{$row["expired_date"]}</td>"; //expiration date
                    echo "<td>{$row["senddate"]}</td>"; //shipped date
                    echo "<td>{$row["received_date"]}</td>"; //shipped date
                    echo "<td>{$row['status']}</td>"; //status
                    echo "<td><div class='checkbox'><input type='checkbox' disabled></div></td>"; //cancel order            

                } else { //canceled
                    echo "<td>{$row["expired_date"]}</td>"; //expiration date
                    echo "<td>{$row["senddate"]}</td>"; //shipped date
                    echo "<td>{$row["received_date"]}</td>"; //shipped date
                    echo "<td>{$row['status']}</td>"; //status
                    echo "<td><div class='checkbox'><input type='checkbox' disabled></div></td>"; //cancel order            

                }
                echo "</tr>";
                
            }

        }
    } else {
        echo "0 results";
    }    
//}


?>
