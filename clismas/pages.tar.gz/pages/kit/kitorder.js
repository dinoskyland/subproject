$(function() {
	var order_no; //popup title
	var order_sum; //order_sum from csm04_KIT_order
	var expiration;

	$('#myModal').on('show.bs.modal', function (event) {
		$("#deliverytable > tbody > tr").remove();
		if (expiration.length) { //expiration is typed in
	    	$.post( "order_no_kitname.php", {order_no: order_no}, function(data) {
	    		//alert(data);
	    		tr='';
				for (i = 0; i < data.length; i++) {
					tr = tr + "<tr>";
					tr = tr + "<td class='kitname'>"+data[i].kit_name+"</td>";
					tr = tr + "<td><input type='text' id='"+data[i].id+"' class='form-control'></td>";
					tr = tr + "</tr>";
				}
				$("#deliverytable > tbody").append(tr);					
	    	},'json')
	    	.fail(function() {
				alert( "error" );
			}); // end ajax call			
			var modal = $(this);
			modal.find('#delivery_order_no').text(order_no);
		} else { //expiration == 0
			tr = "<tr>";
			tr = tr + "<td colspan='2' style='font-weight: bold; color: #ff0000; text-align:center;'>Expiration Date을 먼저 입력해주세요</td>";
			tr = tr + "</tr>";
			$("#deliverytable > tbody").append(tr);		
		}
		
	});

	//save
	$("#delivered").click(function(){
    	$('#myModal').modal('hide');
		var total=0;
		if (expiration.length == 0) {
				//alert( 'Expiration Date을 설정해주세요' );
		} else {
			$('#deliverytable > tbody  > tr').each(function() {
				$this = $(this);
				var kitname = $this.find(".kitname").html();
				var quantity = $this.find("input.form-control").val();
				var id = $this.find("input.form-control").prop('id');
				var pattern_num = /^([0-9]|[0-9][0-9]|[0-9][0-9][0-9])$/;

				if (quantity.length == 0) {
					//blank
				//update send_qty(kits sent) from csm04_KIT_order_detail;_
				} else if (quantity.match(pattern_num)) {
					total += Number(quantity);		
					console.log('total '+total);

					$.post( "delivered.php", {
						order_no:order_no, 
						id:id,
						quantity:quantity
						}, function(data) {
						//console.log("delivered");
						//alert( data );
					})
					.fail(function() {
						alert(data);
					}); // end ajax call				

				} else {
		    		alert("Quantity: 숫자만 입력가능합니다(1~999)\n입력불가: "+kitname);
				}
			});

			console.log('order_sum-total '+order_sum-total);
			//if total is 0, exit
			if (total) {
				order_sum=order_sum-total;					
				if (order_sum<0) {
					order_sum=0;
				}
				$.post( "delivered_sum.php", {
					order_no:order_no, 
					order_sum:order_sum,
					expiration:expiration
					}, function(data) {
					//console.log("delivered");
					//alert( data );
					window.location.href = $("#kitorder").prop('href');
				})
				.fail(function() {
					alert(data);
				}); // end ajax call			
			} 
			//subtract total(kits sent) from order_sum from csm04_KIT_order;_

		
		}

	});


	$(".button-set").click(function(){
    	expiration = $(this).parent().prev().children().val();
	    order_no = $(this).prop('id');
	    order_sum = $(this).prop('name');
	});

	$(".button-received").click(function(){
    	order_no = $(this).prop('id');
    	console.log('button-received id '+order_no);
    	$.post( "received.php", {order_no: order_no}, function(data) {
    		// if (data==order_no) {
	    	alert("수신 처리 되었습니다");	    			
    		// }
			window.location.href = $("#kitorder").prop('href');
    	})
    	.fail(function() {
			alert( "error" );
		}); // end ajax call			
	});

	$('.checkbox_cancel').click(function() {
        if(this.checked) {
            var returnVal = confirm("Order를 삭제하시겠습니까?");
            if (returnVal) {
		    	console.log('checkbox_cancel order_no'+order_no);
		    	order_no = $(this).prop('id');
		    	$.post( "cancel.php", {order_no: order_no}, function(data) {
		    		// if (data==order_no) {
			    	//alert("삭제처리 되었습니다");
		    		// }
					window.location.href = $("#kitorder").prop('href');
		    	})
		    	.fail(function() {
					alert( "error" );
				}); // end ajax call			

	    		//$("#kitorder").click(); //refresh webpage
            }

            //$(this).prop('checked',)
        }
    });


/*	$(".checked").submit(function(event){
		event.preventDefault();
		 // Get from elements values 
		var values = $(this).serialize();

		$.post( "listcheckbox.php",values, function(data) {
			alert( data );
		})
		.fail(function() {
			alert( "error" );
		});
	});
*/
	$("#order").click(function(){
		var protocol = $("#protocol").val();
		var protocolname = $("#protocolname").text();
		var site = $("#site").val();
		var address = $("#address").val();
		var phone = $("#phone").val();
		var requester = $("#requester").val();
		var datepicker = $("#datepicker").val();
		var pattern = /^[ㄱ-ㅎㅏ-ㅣ가-힣\s\w-()]+$/;

		if (!site.match(pattern)) {
			alert("Site명: 문자,순자,(),_,-만 가능합니다");
		} else if (!address.match(pattern)){
			alert("배송주소: 문자,순자,(),_,-만 가능합니다");
		} else if (!phone.match(pattern)){
			alert("전화번호: 순자,(),_,-만 가능합니다");
		} else if (!requester.match(pattern)){
			alert("요청자: 문자,순자,(),_,-만 가능합니다");
		} else if (datepicker.length == 0){
			alert("수령희망일을 입력하세요");
		} else {
			$.post( "order_no.php", function(data) {
				console.log('order_no.'+data);
				var ordersummary = kitorderdetail(data);			
				kitordermaster(data, ordersummary);
			})
			.fail(function() {
				alert(data);
			}); // end ajax call	
			alert('주문이 완료되었습니다');
			window.location.href = $("#kitorder").prop('href');
			//$('#search').trigger('click');
		}


		function kitorderdetail(order_no) {
			//alert(order_no);
			var total=0;
			$('#kittable > tbody  > tr').each(function() {
				$this = $(this);
				var id = $this.find("span.kitname").prop('id');
				var kitname = $this.find("span.kitname").text();
				var quantity = $this.find("input.kitquantity").val();
				var pattern_num = /^([0-9]|[0-9][0-9]|[0-9][0-9][0-9])$/;


				if (quantity.length == 0) {
					//blank
				} else if (quantity.match(pattern_num)) {
					total += Number(quantity);		
					console.log('total '+total);
					$.post( "kitorderdetail.php", {
						order_no:order_no, 
						id:id, 
						kitname:kitname, 
						quantity:quantity, 
						requester:requester, 
						datepicker:datepicker
						}, function(data) {
						console.log("kitorderdetail");
						//alert( data );
					})
					.fail(function() {
						alert(data);
					}); // end ajax call				
				} else {
		    		alert("Quantity: 숫자만 입력가능합니다(1~999)\n입력불가: "+kitname);
				}
				
				//alert( quantity);
			});
			return total;
		}

		function kitordermaster(order_no, ordersummary) {
			//if total of kit orders > 0
			if (ordersummary > 0) {
				$.post( "kitordermaster.php", {
					order_no: order_no, 
		    		protocol: protocol,
		    		protocolname: protocolname,
		    		site: site,
		    		address: address,
		    		phone: phone,
		    		requester: requester,
		    		datepicker: datepicker,
		    		ordersummary: ordersummary}, function(data) {
					console.log("kitordermaster");
					// var json = $.parseJSON(data);
		   			//alert(json.result[0].pl_protocol_name);
					//alert(data);
		        })
		    	.fail(function() {
					alert(data);
				}); // end ajax call   	
			}
		}

	});
	
/*$("#submit").click(function(){
		var protocol = $("#protocol").val();
		$('.ordername').each(function(i, obj) {
			$(this).siblings('tr').prop('value');
			//test
		});
		console.log( "insert kitorder" );
    	$.post( "../protocolsearch.php", {protocol: protocol}, function(data) {
			console.log("protocolsearch");
			// var json = $.parseJSON(data);
   //  		alert(json.result[0].pl_protocol_name);
			$("#protocolname").val(data[0].pl_protocol_name);
			$.post( "searchkit.php", {protocol: protocol}, function(data) {
				console.log("searchkit");
				//alert( "ok2" );
				var tr;
				$("#kitrow").remove();
				$.each(data, function(i, item) {
					tr = "<tr>";
					tr = tr + "<td class=ordername>"+item.kit_name+"</td>";
					tr = tr + "<td><input type='text' class='form-control orderquantity></td>";
					tr = tr + "</tr>";
					$("#kittable").append(tr);					
				});
			},'json')
			.fail(function() {
				alert(data);
			}); // end ajax call					
        },'json')
    	.fail(function() {
			alert( "안건코드 입력확인" );
		}); // end ajax call   		
	});
	*/
});