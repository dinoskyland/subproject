<?php
//display error 
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
include_once 'clisconnect.php';
if (!isset($_SESSION)) {
    session_start(); // Starting Session
}

$temp         = array();
$site         = '';
$address      = '';
$phone        = '';
$requester    = '';
$visitTime    = ''; //from pickup request
$staff1name   = '';
$staff2name   = '';
$staff1phone  = '';
$staff2phone  = '';
$protocol     = $_SESSION['protocol']; // from protocolsearch2.php when registering.
$protocolname = $_SESSION['protocolname'];

//manager
if ($_SESSION['manager'] == 't') {
include_once 'limsconnect.php';
    $phone = $_SESSION['phone']; //phone is saved in searchRequest.php
    $sql   = "SELECT pl_protocol_cd FROM bim07_protocolbase";
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            // echo $row['pl_protocol_cd'];
            if ($row['pl_protocol_cd'] == $protocol) {
                echo "<option selected='selected'>{$row['pl_protocol_cd']}</option>";
            } else {
                echo "<option>{$row['pl_protocol_cd']}</option>";
            }
        }
    } else {
        echo "0 results";
    }
} else { //user
    echo "<option selected='selected'>$protocol</option>";
    $site        = $_SESSION['site'];
    $person      = $_SESSION['person'];
    $address     = $_SESSION['address'];
    $phone       = $_SESSION['phone'];
    $requester   = $_SESSION['person'];
    $temp        = getStaff($site, 1, $connClis);
    $staff1name  = $temp[0][0];
    $staff1phone = $temp[0][1];
    $temp        = getStaff($site, 2, $connClis);
    $staff2name  = $temp[0][0];
    $staff2phone = $temp[0][1];
}

function getStaff($site, $index, $connClis)
{
    
    $temp = array();
    
    if ($index == 1) {
        $index = '주담당자';
    } else {
        $index = '부담당자';
    }
    echo 'aserfgawfgawref';
    $sql = "SELECT manager_name, mobile, role FROM csm03_spl_pickup_request_staff WHERE site_name='$site' and role='$index'";
    
    $result = $connClis->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $temp[] = array(
                $row["manager_name"],
                $row["mobile"]
            );
        }
    } else {
        $temp[] = array(
            '',
            "Pickup Staff가 배정되지 않았습니다"
        );
    }
    
    return $temp;
}

?>
