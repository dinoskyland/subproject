// Bind to the submit event of our form
$(function() {
	$(".linkable-row").click(function(){
    	var values = $(this).val();
    	alert(values);
    	$.post( "subject.php", {id: values}, function(data) {
			alert(data);
    	})
    	.fail(function() {
			alert( "error" );
		});
	});
});