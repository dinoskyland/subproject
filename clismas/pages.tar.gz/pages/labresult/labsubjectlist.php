<?php
//display error 
error_reporting(E_ALL);
ini_set("display_errors", 1);
ini_set('display_startup_errors', 1);

include_once '../clisconnect.php';

if (isset($_POST['submit'])) {
    //echo $_POST['col1'];
    //echo $_POST['col2'];
    
    $sql = "SELECT sp_cd,sp_name,protocol_name,site_name,user_ID,user_PW,user_name,user_contact,user_email,user_address FROM csm01_users";
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            //echo "<tr>";
            echo "<tr>";
            echo "<td><a href=\"javascript:rowlink(" . $row["sp_cd"] . ")\">" . $row["sp_cd"] . "</a></td>";
            echo "<td>" . $row["sp_name"] . "</td>";
            echo "<td>" . $row["protocol_name"] . "</td>";
            echo "<td>" . $row["site_name"] . "</td>";
            echo "<td>" . $row["user_ID"] . "</td>";
            echo "<td>" . $row["user_PW"] . "</td>";
            echo "<td>" . $row["user_name"] . "</td>";
            echo "<td>" . $row["user_contact"] . "</td>";
            echo "<td>" . $row["user_email"] . "</td>";
            echo "<td>" . $row["user_address"] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "0 results";
    }
    
    $conn->close();
}
?>
