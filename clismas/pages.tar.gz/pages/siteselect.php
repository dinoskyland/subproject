<?php			
//display error 
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
include_once 'limsconnect.php';
if(!isset($_SESSION)) { 
	session_start(); // Starting Session
} 

$protocol = $_SESSION['protocol']; // from protocolsearch2.php when registering.
$site = $_SESSION['site']; // from protocolsearch2.php when registering.

$sql = "SELECT ps_site_cd, ps_site_name FROM bim07_protocol_site where protocol_cd='$protocol'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
// output data of each row
	while($row = $result->fetch_assoc()) {
		// echo $row['pl_protocol_cd'];
		if ($row['ps_site_name'] == $site) {
			echo "<option selected='selected'>{$row['ps_site_name']}</option>";		

		} else {
			echo "<option>{$row['ps_site_name']}</option>";		
			
		}
	}
} else {
	echo "0 results";
}


?>
